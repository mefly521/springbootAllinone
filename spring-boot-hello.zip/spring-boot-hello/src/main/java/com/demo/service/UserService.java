package com.demo.service;

public interface UserService {

	void test(int b);
}
