package com.demo.controller;

import lombok.Data;

/**
 * @author mifei
 * @create 2019-11-08 13:17
 **/
@Data
public class User {

    private String username;
    private String age;



}
